ALTER TABLE `#__contentitem_tag_map` DROP INDEX `idx_tag`;
ALTER TABLE `#__contentitem_tag_map` DROP INDEX `idx_type`;
