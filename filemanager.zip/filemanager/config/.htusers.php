<?php 
	// ensure this file is being included by a parent file
	if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
	$GLOBALS["users"]=array(
	//array('admin','$2a$08$nYtVjVQiaAlDNVMPiH4J..DD6DUerjl8yFjGpb0PQcxkkOVVRK9GS','/var/www/html','http://localhost','1','','7',1),
	//array('testuser','$2a$08$R3gQklqe/fya80kikSUbgOUFybTT5lyjHTzoJj9/TvVuzJk3F/EiO','/var/www/html','http://localhost','1','','7',1),
	array('testuser','2cfa00da0a5f9c015d030d2e3722ba65','/var/www/html','http://localhost','1','','7',1),
); 
?>
